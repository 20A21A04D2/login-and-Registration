const forms = document.querySelector(".forms"),
    pwShowHide = document.querySelectorAll(".eye-icon"),
    links = document.querySelectorAll(".link");

pwShowHide.forEach(eyeIcon => {
    eyeIcon.addEventListener("click", () => {
        let pwFields = eyeIcon.parentElement.parentElement.querySelectorAll(".password");

        pwFields.forEach(password => {
            if (password.type === "password") {
                password.type = "text";
                eyeIcon.classList.replace("bx-hide", "bx-show");
                return;
            }
            password.type = "password";
            eyeIcon.classList.replace("bx-show", "bx-hide");
        })

    })
})

links.forEach(link => {
    link.addEventListener("click", e => {
        e.preventDefault(); 
        forms.classList.toggle("show-signup");
    })
})

document.addEventListener("DOMContentLoaded", function () {
    const passwordInput = document.querySelector(".password");
    const strengthMessage = document.createElement("div");
    strengthMessage.classList.add("strength-message");
    passwordInput.parentNode.insertBefore(strengthMessage, passwordInput.nextSibling);

    passwordInput.addEventListener("input", function () {
        const password = passwordInput.value;
        const strength = calculatePasswordStrength(password);

        let message;
        let color;

        if (strength >= 3) {
            message = "Strong Password";
            color = "green";
        } else {
            message = "Weak Password";
            color = "red";
        }

        strengthMessage.textContent = message;
        strengthMessage.style.color = color;
    });

    function calculatePasswordStrength(password) {
        let strength = 0;

        if (password.length >= 8) {
            strength++;
        }

        if (/[A-Z]/.test(password)) {
            strength++;
        }

        if (/[a-z]/.test(password)) {
            strength++;
        }

        if (/\d/.test(password)) {
            strength++;
        }

        if (/[^A-Za-z0-9]/.test(password)) {
            strength++;
        }

        return strength;
    }
});

window.addEventListener('load', function() {
    var rememberMeCheckbox = document.getElementById('rememberMe');
    var userEmailInput = document.getElementById('loginEmail');
    if (localStorage.getItem('rememberedEmail')) {
        userEmailInput.value = localStorage.getItem('rememberedEmail');
        rememberMeCheckbox.checked = true;
    }
    document.getElementById('loginForm').addEventListener('submit', function(event) {
        if (rememberMeCheckbox.checked) {
            localStorage.setItem('rememberedEmail', userEmailInput.value);
        } else {
            localStorage.removeItem('rememberedEmail');
        }
    });
});

document.addEventListener("DOMContentLoaded", function () {
    const signupButton = document.getElementById('signupButton');
    const dialogBox = document.getElementById('dialogBox');
    const loginButtonFromDialog = document.getElementById('loginButtonFromDialog');
    const forms = document.querySelector('.forms');

    function isSignupFormValid() {
        const username = document.querySelector('.signup .input[type="text"]').value;
        const email = document.querySelector('.signup .input[type="email"]').value;
        const password = document.querySelector('.signup .password').value;

        return username && email && password;
    }

    signupButton.addEventListener('click', function () {
        if (isSignupFormValid()) {
            dialogBox.style.display = 'block';
        } else {
            console.log('Please fill in all sign-up fields.');
        }
    });

    loginButtonFromDialog.addEventListener('click', function () {
        window.location.href = 'index.html';
    });

    document.querySelector('.login-link').addEventListener('click', function (event) {
        event.preventDefault();
    });
});

document.addEventListener("DOMContentLoaded", function() {
    const loginButton = document.getElementById("loginButton");
    loginButton.addEventListener("click", function(event) {
        event.preventDefault();
        const email = document.querySelector(".input[type='email']").value;
        const password = document.querySelector(".password").value;
        if (email && password) {
            window.location.href = "C:\Users\subba\Downloads\Registration-form-main\Registration-form-main\Registration-form-main\success.html";
        } else {
            console.log("Invalid login credentials");
        }
    });
});
